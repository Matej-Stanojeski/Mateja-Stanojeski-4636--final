using DI.Contexts.Interfaces;
using DI.DTOs;
using DI.Infrastructure.Providers;
using DI.Models;
using DI.Services;
using DI.Services.Interfaces;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace DI.Tests
{
    public class StudentServiceTest
    {
        private readonly Mock<IDbContext> _context;
        private readonly Mock<IRandomProvider> _random;
        private readonly Mock<ICurrentTimeProvider> _currentTime;
        private readonly IStudentService _studentService;

        public StudentServiceTest()
        {
            _context = new Mock<IDbContext>();
            _random = new Mock<IRandomProvider>();
            _currentTime = new Mock<ICurrentTimeProvider>();

            _studentService = new StudentService(_context.Object, _random.Object, _currentTime.Object);
        }

        [Fact]
        public void RandomStudentsFromTodayWhenCalledReturnsStudents()
        {
            // Arrage 
            var enrolledBefore = 3;
            var maxPageSize = 4;
            var expectedStudents = new List<Student>
            {
                new Student
                {
                    Id = 1,
                    StudentIndex = "3516",
                    FirstName = "Kassidy",
                    LastName = "Trueman",
                    DOB = DateTime.Today.AddYears(-22).AddDays(100),
                    EnrollmentDate = DateTime.Today.AddYears(-3),
                    Mail = "Kassidy.Trueman@mail.com",
                    GPA = 4
                },
                new Student
                {
                    Id = 2,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(140),
                    FirstName = "Christobel",
                    LastName = "Bezuidenhout",
                    Mail = "Christobel.Bezuidenhout@mail.com",
                    StudentIndex = "1241",
                    GPA = 3.6m
                },
                new Student
                {
                    Id = 3,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(120),
                    FirstName = "Kristel",
                    LastName = "Madison",
                    Mail = "Kristel.Madison@mail.com",
                    StudentIndex = "3121",
                    GPA = 3.8m
                },
                new Student
                {
                    Id = 4,
                    DOB = DateTime.Today.AddYears(-22).AddDays(20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(200),
                    FirstName = "Lyndsey",
                    LastName = "Albers",
                    Mail = "Lyndsey.Albers@mail.com",
                    StudentIndex = "1415",
                    GPA = 4.6m
                },
                new Student
                {
                    Id = 5,
                    DOB = DateTime.Today.AddYears(-22).AddDays(120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(110),
                    FirstName = "Alishia",
                    LastName = "Gabriels",
                    Mail = "Alishia.Gabriels@mail.com",
                    StudentIndex = "3717",
                    GPA = 4.1m
                }
            };

            _currentTime.Setup(x => x.Now())
                .Returns(DateTime.Now);
            _random.Setup(x => x.Number(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(4);
            _context.Setup(x => x.GetStudents())
                .Returns(expectedStudents);

            // Act 
            var result = _studentService.RandomStudentsFromToday(enrolledBefore, maxPageSize);

            // Assert 
            Assert.NotEmpty(result);
            Assert.InRange(result.Count(), 1, maxPageSize);
            Assert.IsType<List<StudentResult>>(result);
        }

        [Fact]
        public void RandomStudentsFromTodayWhenCalledReturnsEmptyStudentsEnrolledBeforeToday()
        {
            //Arrange
            var enrolledBefore = 0;
            var maxPageSize = 4;
            var expectedStudents = new List<Student>
            {
                new Student
                {
                    Id = 1,
                    StudentIndex = "3516",
                    FirstName = "Kassidy",
                    LastName = "Trueman",
                    DOB = DateTime.Today.AddYears(-22).AddDays(100),
                    EnrollmentDate = DateTime.Today.AddYears(-3),
                    Mail = "Kassidy.Trueman@mail.com",
                    GPA = 4
                },
                new Student
                {
                    Id = 2,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(140),
                    FirstName = "Christobel",
                    LastName = "Bezuidenhout",
                    Mail = "Christobel.Bezuidenhout@mail.com",
                    StudentIndex = "1241",
                    GPA = 3.6m
                },
                new Student
                {
                    Id = 3,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(120),
                    FirstName = "Kristel",
                    LastName = "Madison",
                    Mail = "Kristel.Madison@mail.com",
                    StudentIndex = "3121",
                    GPA = 3.8m
                },
                new Student
                {
                    Id = 4,
                    DOB = DateTime.Today.AddYears(-22).AddDays(20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(200),
                    FirstName = "Lyndsey",
                    LastName = "Albers",
                    Mail = "Lyndsey.Albers@mail.com",
                    StudentIndex = "1415",
                    GPA = 4.6m
                },
                new Student
                {
                    Id = 5,
                    DOB = DateTime.Today.AddYears(-22).AddDays(120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(110),
                    FirstName = "Alishia",
                    LastName = "Gabriels",
                    Mail = "Alishia.Gabriels@mail.com",
                    StudentIndex = "3717",
                    GPA = 4.1m
                }
            };
            _currentTime.Setup(x => x.Now())
            .Returns(DateTime.Now);
            _random.Setup(x => x.Number(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(maxPageSize);
            _context.Setup(x => x.GetStudents())
                .Returns(expectedStudents);

            // Act
            var result = _studentService.RandomStudentsFromToday(enrolledBefore, maxPageSize);

            //Assert
            Assert.NotNull(result);
            Assert.Empty(result);
        }

        [Fact]
        public void RandomStudentsFromTodayWhenCalledReturnsMaxStudents()
        {
            // Arrange
            var enrolledBefore = 3;
            var maxPageSize = 2;
            var expectedStudents = new List<Student>
            {
                new Student
                {
                    Id = 1,
                    StudentIndex = "3516",
                    FirstName = "Kassidy",
                    LastName = "Trueman",
                    DOB = DateTime.Today.AddYears(-22).AddDays(100),
                    EnrollmentDate = DateTime.Today.AddYears(-3),
                    Mail = "Kassidy.Trueman@mail.com",
                    GPA = 4
                },
                new Student
                {
                    Id = 2,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(140),
                    FirstName = "Christobel",
                    LastName = "Bezuidenhout",
                    Mail = "Christobel.Bezuidenhout@mail.com",
                    StudentIndex = "1241",
                    GPA = 3.6m
                },
                new Student
                {
                    Id = 3,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(120),
                    FirstName = "Kristel",
                    LastName = "Madison",
                    Mail = "Kristel.Madison@mail.com",
                    StudentIndex = "3121",
                    GPA = 3.8m
                },
                new Student
                {
                    Id = 4,
                    DOB = DateTime.Today.AddYears(-22).AddDays(20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(200),
                    FirstName = "Lyndsey",
                    LastName = "Albers",
                    Mail = "Lyndsey.Albers@mail.com",
                    StudentIndex = "1415",
                    GPA = 4.6m
                },
                new Student
                {
                    Id = 5,
                    DOB = DateTime.Today.AddYears(-22).AddDays(120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(110),
                    FirstName = "Alishia",
                    LastName = "Gabriels",
                    Mail = "Alishia.Gabriels@mail.com",
                    StudentIndex = "3717",
                    GPA = 4.1m
                }
            };
            _currentTime.Setup(x => x.Now())
            .Returns(DateTime.Now);
            _random.Setup(x => x.Number(It.IsAny<int>(), It.IsAny<int>()))
                .Returns(maxPageSize);
            _context.Setup(x => x.GetStudents())
                .Returns(expectedStudents);

            //Act
            var result = _studentService.RandomStudentsFromToday(enrolledBefore, maxPageSize);

            //Assert
            Assert.NotNull(result);
            Assert.NotEmpty(result);
            Assert.Equal(maxPageSize, result.Count());
        }
    }
}
