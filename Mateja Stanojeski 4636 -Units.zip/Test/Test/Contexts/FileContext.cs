﻿using DI.Contexts.Interfaces;
using DI.Infrastructure;
using DI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Contexts
{
    public class FileContext : IDbContext
    {
        private readonly string _connection;
        public FileContext(IAppSettings appSettings)
        {
            this._connection = appSettings.ConnectionString;
        }

        public List<Student> GetStudents()
        {
            var json = File.ReadAllText(_connection);
            return JsonConvert.DeserializeObject<List<Student>>(json);
        }
    }
}
