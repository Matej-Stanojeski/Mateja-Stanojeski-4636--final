﻿using DI.Contexts.Interfaces;
using DI.Infrastructure;
using DI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Contexts
{
    public class MemoryContext : IDbContext
    {
        private readonly string _connection;
        public MemoryContext(IAppSettings appSettings)
        {
            this._connection = appSettings.ConnectionString;
        }

        public List<Student> GetStudents() => new List<Student>
        {
             new Student
                {
                    Id = 1,
                    StudentIndex = "3516",
                    FirstName = "Kassidy",
                    LastName = "Trueman",
                    DOB = DateTime.Today.AddYears(-22).AddDays(100),
                    EnrollmentDate = DateTime.Today.AddYears(-3),
                    Mail = "Kassidy.Trueman@mail.com",
                    GPA = 4
                },
                new Student
                {
                    Id = 2,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(140),
                    FirstName = "Christobel",
                    LastName = "Bezuidenhout",
                    Mail = "Christobel.Bezuidenhout@mail.com",
                    StudentIndex = "1241",
                    GPA = 3.6m
                },
                new Student
                {
                    Id = 3,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(120),
                    FirstName = "Kristel",
                    LastName = "Madison",
                    Mail = "Kristel.Madison@mail.com",
                    StudentIndex = "3121",
                    GPA = 3.8m
                },
                new Student
                {
                    Id = 4,
                    DOB = DateTime.Today.AddYears(-22).AddDays(20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(200),
                    FirstName = "Lyndsey",
                    LastName = "Albers",
                    Mail = "Lyndsey.Albers@mail.com",
                    StudentIndex = "1415",
                    GPA = 4.6m
                },
                new Student
                {
                    Id = 5,
                    DOB = DateTime.Today.AddYears(-22).AddDays(120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(110),
                    FirstName = "Alishia",
                    LastName = "Gabriels",
                    Mail = "Alishia.Gabriels@mail.com",
                    StudentIndex = "3717",
                    GPA = 4.1m
                },
                new Student
                {
                    Id = 1,
                    StudentIndex = "3516",
                    FirstName = "Kassidy",
                    LastName = "Trueman",
                    DOB = DateTime.Today.AddYears(-22).AddDays(100),
                    EnrollmentDate = DateTime.Today.AddYears(-3),
                    Mail = "Kassidy.Trueman@mail.com",
                    GPA = 4
                },
                new Student
                {
                    Id = 2,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(140),
                    FirstName = "Christobel",
                    LastName = "Bezuidenhout",
                    Mail = "Christobel.Bezuidenhout@mail.com",
                    StudentIndex = "1241",
                    GPA = 3.6m
                },
                new Student
                {
                    Id = 3,
                    DOB = DateTime.Today.AddYears(-22).AddDays(-120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(120),
                    FirstName = "Kristel",
                    LastName = "Madison",
                    Mail = "Kristel.Madison@mail.com",
                    StudentIndex = "3121",
                    GPA = 3.8m
                },
                new Student
                {
                    Id = 4,
                    DOB = DateTime.Today.AddYears(-22).AddDays(20),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(200),
                    FirstName = "Lyndsey",
                    LastName = "Albers",
                    Mail = "Lyndsey.Albers@mail.com",
                    StudentIndex = "1415",
                    GPA = 4.6m
                },
                new Student
                {
                    Id = 5,
                    DOB = DateTime.Today.AddYears(-22).AddDays(120),
                    EnrollmentDate = DateTime.Today.AddYears(-3).AddDays(110),
                    FirstName = "Alishia",
                    LastName = "Gabriels",
                    Mail = "Alishia.Gabriels@mail.com",
                    StudentIndex = "3717",
                    GPA = 4.1m
                }
        };

    }
}
