﻿using DI.Contexts.Interfaces;
using DI.Infrastructure;
using DI.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Contexts
{
    public class DbContext : IDbContext
    {
        private readonly string _connection;
        public DbContext(IAppSettings appSettings)
        {
            this._connection = appSettings.ConnectionString;
        }

        public List<Student> GetStudents()
        {
            SqlConnection conn = new SqlConnection(_connection);
            SqlDataReader rdr = null;
            List<Student> students = new List<Student>();
            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("SELECT Id, FirstName, LastName, StudentIndex, Mail, EnrollmentDate, DateOfBirth, GPA FROM [dbo].[Students]", conn);
                
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Student student = new Student
                    {
                        Id = Convert.ToInt32(rdr[0]),
                        FirstName = rdr[1].ToString(),
                        LastName = rdr[2].ToString(),
                        StudentIndex = rdr[3].ToString(),
                        Mail = rdr[4].ToString(),
                        EnrollmentDate = string.IsNullOrEmpty(rdr[5].ToString())
                        ? (DateTime?)null
                        : Convert.ToDateTime(rdr[5].ToString()),
                        DOB = string.IsNullOrEmpty(rdr[6].ToString())
                        ? (DateTime?)null
                        : Convert.ToDateTime(rdr[6].ToString()),
                        GPA = string.IsNullOrEmpty(rdr[7].ToString())
                        ? (decimal?)null
                        : Convert.ToDecimal(rdr[7].ToString())
                    };
                    students.Add(student);
                }
            }
            catch(Exception e)
            {

            }
            finally
            {
                if (rdr != null)
                {
                    rdr.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }

            return students;
        }
    }
}
