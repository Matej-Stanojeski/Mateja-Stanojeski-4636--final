﻿using DI.Contexts;
using DI.Contexts.Interfaces;
using DI.Infrastructure;
using DI.Infrastructure.Providers;
using DI.Services;
using DI.Services.Interfaces;
using SimpleInjector;
using System;

namespace DI
{
    class Program
    {
        static void Main(string[] args)
        {
            var container = new Container();

            container.Register<IAppSettings, AppSettings>();
            container.Register<IRandomProvider, RandomProvider>();
            container.Register<ICurrentTimeProvider, CurrentTimeProvider>();
            container.Register<IDbContext, FileContext>();
            container.Register<IStudentService, StudentService>();

            container.Verify();

            var studentService = container.GetInstance<IStudentService>();

            //var appSettings = new AppSettings();
            //var context = new MemoryContext(appSettings);
            //var context = new DbContext(appSettings);
            //var context = new FileContext(appSettings);
            //var random = new RandomProvider();
            //var currentTime = new CurrentTimeProvider();
            //var studentService = new StudentService(context, random, currentTime);

            var students = studentService.RandomStudentsFromToday(3, 20);

            foreach (var student in students)
            {
                Console.WriteLine(student);
            }
        }
    }
}
