﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.DTOs
{
    public class StudentResult
    { 
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? EnrollmentDate { get; set; }
        public DateTime? DOB { get; set; }
        public string StudentIndex { get; set; }
        public decimal? GPA { get; set; }
        public override string ToString()
        {
            return $"{StudentIndex}: {FirstName} {LastName} ({EnrollmentDate.Value:dd.MM.yyyy} - {GPA}";
        }
    }
}
