﻿using DI.Contexts.Interfaces;
using DI.DTOs;
using DI.Infrastructure.Providers;
using DI.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Services
{
    public class StudentService : IStudentService
    {
        private readonly IDbContext database;
        private readonly IRandomProvider random;
        private readonly ICurrentTimeProvider currentTime;
        public StudentService(IDbContext database, IRandomProvider random, ICurrentTimeProvider currentTime)
        {
            this.database = database;
            this.random = random;
            this.currentTime = currentTime;
        }

        public IEnumerable<StudentResult> RandomStudentsFromToday(int enrolledBefore, int maxPageSize)
        {
            var enrollmentDate = currentTime.Now().AddYears(-enrolledBefore);
            var totalStudents = random.Number(1, maxPageSize);

            var allStudents = database
                .GetStudents()
                .Where(c => c.EnrollmentDate > enrollmentDate)
                .Take(totalStudents)
                .Select(c => new StudentResult
                {
                    FirstName = c.FirstName,
                    LastName = c.LastName,
                    EnrollmentDate = c.EnrollmentDate,
                    StudentIndex = c.StudentIndex,
                    GPA = c.GPA
                }).ToList();

            return allStudents;
        }
    }
}
