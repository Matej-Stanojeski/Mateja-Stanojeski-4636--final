﻿using DI.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Services.Interfaces
{
    public interface IStudentService
    {
        IEnumerable<StudentResult> RandomStudentsFromToday(int enrolledBefore, int maxPageSize);
    }
}
