﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DI.Infrastructure
{
    public class AppSettings : IAppSettings
    {
        //public string ConnectionString { get; } = "Server=localhost;Database=uacsIS_DB;User Id=sa;Password=!2E45678;MultipleActiveResultSets=true";
        public string ConnectionString { get; } = "C:/Users/monika.arsenovska/Desktop/UACS/UACS 2021/Spring 2022/IS/week10/DI/DI/Data/students.json";
    }
}
